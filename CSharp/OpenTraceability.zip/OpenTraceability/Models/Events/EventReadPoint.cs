﻿namespace OpenTraceability.Models.Events
{
    public class EventReadPoint
    {
        public string ID { get; set; } = string.Empty;
    }
}