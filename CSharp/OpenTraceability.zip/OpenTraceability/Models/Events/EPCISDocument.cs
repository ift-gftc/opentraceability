﻿namespace OpenTraceability.Models.Events
{
    public class EPCISDocument : EPCISBaseDocument
    {
    }
}