﻿namespace OpenTraceability.Models.Common
{
    public class SBDHOrganization
    {
        public string Identifier { get; set; } = string.Empty;
        public string ContactName { get; set; } = string.Empty;
        public string EmailAddress { get; set; } = string.Empty;
    }
}