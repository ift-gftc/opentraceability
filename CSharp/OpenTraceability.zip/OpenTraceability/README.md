﻿# Open Traceability
This is an open-source library for handling traceability data.